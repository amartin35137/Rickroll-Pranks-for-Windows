___________________
Warning !         |
__________________|
__________________________________________________
Please restart the computer to apply the changes
after the installation
__________________________________________________

You can customize the displayed message and the title of the window by doing the steps above.

If the "Uninstall" file doesn't work, the part above is for you !

To uninstall manually, follow these steps:
1- Open the regedit (If you don't know how read the file "Open regedit"in the "Help" folder)
2- Go to HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon
3- Open "LegalNoticeCaption"
4- Clear the data of the DWORD value (you can type a custom message in the "value" text zone)
5- Do the step 3 and 4 for the DWORD value of "LegalNoticeText"
6- Restart to apply changes
--------------------------------------------------
All rights reserved, AlphaRocket35
